A := FILTER lineitem BY shipdate < commitdate AND receiptdate >= 19940101 AND receiptdate < 19940201 AND commitdate < receiptdate;
B := SELECT orderkey AS ok FROM A;
STORE B INTO 'mytest.txt' USING ('|');

