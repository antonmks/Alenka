L := LOAD 'lineorder' BINARY AS (lo_partkey{4}:int, lo_suppkey{5}:int, lo_orderdate{6}:int, lo_revenue{13}:decimal);
D := LOAD 'date' BINARY AS (d_datekey{1}:int, d_year{5}:int);
S := LOAD 'supplier' BINARY AS (s_suppkey{1}:int, s_region{6}:varchar(12));
P := LOAD 'part' BINARY AS (p_partkey{1}:int, p_brand{5}:varchar(9));

PF := FILTER P BY (p_brand == "MFGR#2221");
SF := FILTER S BY s_region == "EUROPE";

LS := SELECT lo_revenue AS lo_revenue, d_year AS d_year, p_brand AS p_brand
      FROM L JOIN SF on lo_suppkey = s_suppkey
             JOIN PF on lo_partkey = p_partkey
             JOIN D on lo_orderdate = d_datekey;

	  
R := SELECT SUM(lo_revenue) AS lo_revenue1, d_year AS d_year1, p_brand AS p_brand1 FROM LS
     GROUP BY d_year, p_brand;
	 
R1 := ORDER R BY d_year1, p_brand1;		 
	 
STORE R1 INTO 'ss23.txt' USING ('|');