L := LOAD 'lineorder' BINARY AS (lo_custkey{3}:int, lo_partkey{4}:int, lo_suppkey{5}:int, lo_orderdate{6}:int, lo_revenue{13}:decimal, lo_supplycost{14}:decimal);

D := LOAD 'date' BINARY AS (d_datekey{1}:int, d_year{5}:int);
DF := FILTER D BY d_year == 1997 OR d_year == 1998;
S := LOAD 'supplier' BINARY AS (s_suppkey{1}:int, s_nation{5}:varchar(15),  s_region{6}:varchar(12));
SF := FILTER S BY s_region == "AMERICA";
P := LOAD 'part' BINARY AS (p_partkey{1}:int,  p_mfgr{3}:varchar(6), p_category{4}:varchar(12));
PF := FILTER P BY p_mfgr == "MFGR#1" OR p_mfgr == "MFGR#2";

C := LOAD 'customer' BINARY AS (c_custkey{1}:int, c_region{6}:varchar(12));
CF := FILTER C BY c_region == "AMERICA";


LS := SELECT lo_revenue AS lo_revenue, d_year AS d_year, lo_supplycost AS lo_supplycost, s_nation AS s_nation,
             p_category AS p_category
      FROM L JOIN SF on lo_suppkey = s_suppkey
             JOIN CF on lo_custkey = c_custkey
             JOIN PF on lo_partkey = p_partkey
             JOIN DF on lo_orderdate = d_datekey;

R := SELECT d_year AS d_year1, s_nation AS s_nation1, p_category AS p_category1,
            SUM(lo_revenue-lo_supplycost) AS lo_revenue1  FROM LS
     GROUP BY d_year, s_nation, p_category;

	 
R1 := ORDER R BY d_year1, s_nation1, p_category1;		 
	 
STORE R1 INTO 'ss42.txt' USING ('|');