A := LOAD 'lineorder' BINARY AS (lo_orderdate{6}:int, lo_quantity{9}:int, lo_extendedprice{10}:decimal, lo_discount{12}:int);
B := LOAD 'date' BINARY AS (d_datekey{1}:int, d_year{5}:int);
BF := FILTER B BY d_year == 1993;
AF := FILTER A BY lo_quantity < 25 AND lo_discount >= 1 AND lo_discount <= 3;
AJ := SELECT lo_extendedprice AS lo_extendedprice, lo_discount AS lo_discount
      FROM AF JOIN BF on lo_orderdate = d_datekey;
D := SELECT SUM(lo_extendedprice*lo_discount) AS revenue FROM AJ;
STORE D INTO 'ss11.txt' USING ('|');