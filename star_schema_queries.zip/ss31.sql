L := LOAD 'lineorder' BINARY AS (lo_custkey{3}:int, lo_suppkey{5}:int, lo_orderdate{6}:int, lo_revenue{13}:decimal);

D := LOAD 'date' BINARY AS (d_datekey{1}:int, d_year{5}:int);
DF := FILTER D BY d_year >= 1992 AND d_year <= 1997;

S := LOAD 'supplier' BINARY AS (s_suppkey{1}:int, s_nation{5}:varchar(15), s_region{6}:varchar(12));
SF := FILTER S BY s_region == "ASIA";

C := LOAD 'customer' BINARY AS (c_custkey{1}:int, c_nation{5}:varchar(15), c_region{6}:varchar(12));
CF := FILTER C BY c_region == "ASIA";

LS := SELECT lo_revenue AS lo_revenue, d_year AS d_year, s_nation AS s_nation, c_nation AS c_nation
      FROM L JOIN SF on lo_suppkey = s_suppkey
             JOIN CF on lo_custkey = c_custkey
             JOIN DF on lo_orderdate = d_datekey;

R := SELECT SUM(lo_revenue) AS lo_revenue1, d_year AS d_year1, c_nation AS c_nation1, s_nation AS s_nation1 FROM LS
     GROUP BY c_nation, s_nation, d_year;
	 
 
R1 := ORDER R BY d_year1 ASC, lo_revenue1 DESC;		 
	 
STORE R1 INTO 'ss31.txt' USING ('|');