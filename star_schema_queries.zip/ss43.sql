L := LOAD 'lineorder' BINARY AS (lo_custkey{3}:int, lo_partkey{4}:int, lo_suppkey{5}:int, lo_orderdate{6}:int, lo_revenue{13}:decimal, lo_supplycost{14}:decimal);

D := LOAD 'date' BINARY AS (d_datekey{1}:int, d_year{5}:int);
DF := FILTER D BY d_year == 1997 OR d_year == 1998;

S := LOAD 'supplier' BINARY AS (s_suppkey{1}:int, s_city{4}:varchar(10), s_nation{5}:varchar(15),  s_region{6}:varchar(12));
SF := FILTER S BY s_nation == "UNITED STATES";

P := LOAD 'part' BINARY AS (p_partkey{1}:int,  p_category{4}:varchar(12), p_brand{5}:varchar(9));
PF := FILTER P BY p_category == "MFGR#14";

C := LOAD 'customer' BINARY AS (c_custkey{1}:int, c_region{6}:varchar(12));
CF := FILTER C BY c_region == "AMERICA";


LD := SELECT lo_revenue AS lo_revenue, lo_supplycost AS lo_supplycost, d_year AS d_year, s_city AS s_city,
             p_brand AS p_brand
      FROM L JOIN DF on lo_orderdate = d_datekey
             JOIN SF on lo_suppkey = s_suppkey
             JOIN CF on lo_custkey = c_custkey
             JOIN PF on lo_partkey = p_partkey;

R := SELECT d_year AS d_year1, s_city AS s_city1,
            p_brand AS p_brand1, SUM(lo_revenue-lo_supplycost) AS lo_revenue FROM LD
     GROUP BY d_year, s_city, p_brand;
	 
	 
R1 := ORDER R BY d_year1 ASC, s_city1 ASC, p_brand1 ASC;		 
	 
STORE R1 INTO 'ss43.txt' USING ('|');