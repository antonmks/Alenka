C := LOAD 'customer' BINARY AS (c_custkey{1}:int, c_city{4}:varchar(10), c_nation{5}:varchar(15));
CF := FILTER C BY c_nation == "UNITED STATES";

L := LOAD 'lineorder' BINARY AS (lo_custkey{3}:int, lo_suppkey{5}:int, lo_orderdate{6}:int, lo_revenue{13}:decimal);

D := LOAD 'date' BINARY AS (d_datekey{1}:int, d_year{5}:int);
DF := FILTER D BY d_year >= 1992 AND d_year <= 1997;

S := LOAD 'supplier' BINARY AS (s_suppkey{1}:int, s_city{4}:varchar(10), s_nation{5}:varchar(15));
SF := FILTER S BY s_nation == "UNITED STATES";

LS := SELECT lo_revenue AS lo_revenue, d_year AS d_year, c_city AS c_city, s_city AS s_city
      FROM L JOIN SF on lo_suppkey = s_suppkey
             JOIN CF on lo_custkey = c_custkey
             JOIN DF on lo_orderdate = d_datekey;

R := SELECT SUM(lo_revenue) AS lo_revenue1, d_year AS d_year1, c_city AS c_city1, s_city AS s_city1 FROM LS
     GROUP BY c_city, s_city, d_year;
	 
R1 := ORDER R BY d_year1 ASC, lo_revenue1 DESC;		 
	 
STORE R1 INTO 'ss32.txt' USING ('|');