A := LOAD 'lineitem' BINARY AS (l_partkey{2}:int, l_shipinstruct{14}:varchar(25));
B := LOAD 'part' BINARY AS(p_partkey{1}:int);

J := SELECT l_shipinstruct AS l_shipinstruct FROM A JOIN B on l_partkey = p_partkey;
G := SELECT l_shipinstruct AS si, COUNT(l_shipinstruct) AS cnt FROM J GROUP BY l_shipinstruct;
R := ORDER G BY cnt DESC;
STORE R INTO 'skill_top10.txt' USING ('|') LIMIT 10;
