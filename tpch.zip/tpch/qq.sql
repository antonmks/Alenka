L := LOAD 'lineitem20' BINARY AS (l_orderkey{1}:int,  price{6}:decimal, discount{7}:decimal, shipdate{11}:int);
DISPLAY L USING ('|') LIMIT 10000;	