A := LOAD 'lineitemt.tbl' USING ('|') AS ( comment{16}:varchar(44));
STORE A INTO 'lineitemt' BINARY;