_A1 := SELECT  c_mktsegment AS c_mktsegment, SUM(acctbal) AS col2 FROM customer GROUP BY c_mktsegment;
DISPLAY _A1 USING ('|');