LF := FILTER lineitem BY shipdate >= 19950101 AND shipdate <= 19961231;

NF1 := FILTER nation BY n_name == "FRANCE" OR n_name == "GERMANY";

NF := SELECT n_name AS n_name1, n_nationkey AS n_nationkey FROM NF1;
  
SN := SELECT  s_suppkey AS s_suppkey, n_name1 AS n_name1
      FROM supplier JOIN NF ON s_nationkey = n_nationkey;
	  
LJ := SELECT suppkey AS suppkey, price AS price, discount AS discount, shipdate AS shipdate, n_name AS n_name
       FROM LF JOIN orders ON orderkey = o_orderkey
	           JOIN customer ON o_custkey = c_custkey
	           JOIN NF1 ON c_nationkey = n_nationkey;  	
			   
LS := SELECT price AS price, discount AS discount, n_name1 AS n_name1, shipdate AS shipdate, n_name AS n_name
       FROM LJ JOIN SN ON suppkey = s_suppkey;   	   
	   
LF1 := FILTER LS BY n_name1 != n_name;
				
G := SELECT n_name1 AS supp_nation, n_name AS cust_nation, YEAR(shipdate) AS shipyear, SUM(price*(1-discount)) AS revenue
     FROM LF1
     GROUP BY n_name1, n_name, shipyear; 	 
	 
GO := ORDER G BY supp_nation ASC, cust_nation ASC, shipyear ASC;	 
				
STORE GO INTO 'mytest.txt' USING ('|');	
