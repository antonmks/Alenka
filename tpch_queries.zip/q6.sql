B := FILTER lineitem BY discount >= 0.05 AND discount <= 0.07 AND qty < 24 AND shipdate >= 19940101 AND shipdate < 19950101;
C := SELECT MAX(price*discount) AS revenue FROM B;			
STORE C INTO 'mytest.txt' USING ('|') LIMIT 1000;